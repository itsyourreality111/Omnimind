-- Enable pgvector
create extension if not exists vector;

-- ── USER PROFILES ─────────────────────────────────────────
create table if not exists user_profiles (
  id uuid default gen_random_uuid() primary key,
  user_id text unique not null,  -- Clerk user ID
  professional_identity text,
  writing_style text,
  communication_tone text default 'casual',
  active_goals text[],
  pain_points text[],
  key_relationships jsonb default '[]',
  industry text,
  content_topics text[],
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ── KNOWLEDGE CHUNKS (vector store) ───────────────────────
create table if not exists knowledge_chunks (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  content text not null,
  source text not null,      -- e.g. "gmail:inbox", "notion:page-title"
  embedding vector(3072),    -- text-embedding-3-large dimension
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

-- Vector similarity search index
create index if not exists knowledge_chunks_embedding_idx
  on knowledge_chunks
  using ivfflat (embedding vector_cosine_ops)
  with (lists = 100);

-- RLS: users only see their own chunks
alter table knowledge_chunks enable row level security;
create policy "Users own their chunks"
  on knowledge_chunks for all
  using (user_id = auth.uid()::text);

-- ── SEMANTIC SEARCH FUNCTION ───────────────────────────────
create or replace function match_knowledge_chunks(
  query_embedding vector(3072),
  match_user_id text,
  match_count int default 8
)
returns table (
  id uuid,
  content text,
  source text,
  similarity float
)
language sql stable
as $$
  select
    id,
    content,
    source,
    1 - (embedding <=> query_embedding) as similarity
  from knowledge_chunks
  where user_id = match_user_id
  order by embedding <=> query_embedding
  limit match_count;
$$;

-- ── SUBSCRIPTIONS ─────────────────────────────────────────
create table if not exists subscriptions (
  id uuid default gen_random_uuid() primary key,
  user_id text unique not null,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan text default 'free',   -- free | solo | operator | empire
  status text default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ── AGENT LOGS ────────────────────────────────────────────
create table if not exists agent_logs (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  agent_type text not null,   -- writer | scanner | revenue | scheduler | ingestion
  message text not null,
  status text default 'done', -- done | review | sent | failed
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

create index if not exists agent_logs_user_created
  on agent_logs (user_id, created_at desc);

-- ── CONTENT QUEUE ─────────────────────────────────────────
create table if not exists content_queue (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  type text not null,          -- linkedin | twitter | newsletter | blog
  content text not null,
  status text default 'pending_review', -- pending_review | approved | published | rejected
  agent text default 'writer',
  metadata jsonb default '{}',  -- e.g. { thread: [...tweets] }
  scheduled_for timestamptz,
  created_at timestamptz default now()
);

-- ── USER STATS (materialized) ─────────────────────────────
create table if not exists user_stats (
  user_id text primary key,
  hours_freed numeric default 0,
  content_queued int default 0,
  leads_found int default 0,
  mrr_impact numeric default 0,
  updated_at timestamptz default now()
);

-- ── CHAT CONVERSATIONS ────────────────────────────────────
create table if not exists conversations (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  messages jsonb default '[]',  -- [{role, content, timestamp}]
  title text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
