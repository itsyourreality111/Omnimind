import { auth } from '@clerk/nextjs/server'
import { NextRequest } from 'next/server'
import { ragChat } from '@/lib/anthropic/client'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  const { userId } = auth()
  if (!userId) return new Response('Unauthorized', { status: 401 })

  const { message, history = [] } = await req.json()

  if (!message?.trim()) {
    return new Response('Message required', { status: 400 })
  }

  try {
    const stream = await ragChat(message, userId, history)

    // Stream the response to the client
    const encoder = new TextEncoder()
    const readable = new ReadableStream({
      async start(controller) {
        for await (const chunk of stream) {
          if (
            chunk.type === 'content_block_delta' &&
            chunk.delta.type === 'text_delta'
          ) {
            controller.enqueue(encoder.encode(chunk.delta.text))
          }
        }
        controller.close()
      },
    })

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Transfer-Encoding': 'chunked',
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (error: any) {
    console.error('Chat error:', error)
    return new Response(error.message, { status: 500 })
  }
}
