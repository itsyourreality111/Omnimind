import type { Metadata } from 'next'
import { ClerkProvider } from '@clerk/nextjs'
import { Syne, DM_Mono, Instrument_Serif } from 'next/font/google'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  weight: ['400', '600', '700', '800'],
})

const dmMono = DM_Mono({
  subsets: ['latin'],
  variable: '--font-dm-mono',
  weight: ['300', '400'],
})

const instrumentSerif = Instrument_Serif({
  subsets: ['latin'],
  variable: '--font-instrument-serif',
  weight: '400',
  style: ['normal', 'italic'],
})

export const metadata: Metadata = {
  title: 'OmniMind — The AI That Runs Your Business',
  description: 'An AI operating system that autonomously handles your emails, content, deals, and revenue while you sleep.',
  openGraph: {
    title: 'OmniMind',
    description: 'Your business runs while you sleep.',
    url: 'https://omnimind.ai',
    siteName: 'OmniMind',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'OmniMind',
    description: 'Your business runs while you sleep.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${syne.variable} ${dmMono.variable} ${instrumentSerif.variable}`}>
        <body className="bg-[#05080f] text-slate-200 font-sans antialiased">
          {children}
        </body>
      </html>
    </ClerkProvider>
  )
}
