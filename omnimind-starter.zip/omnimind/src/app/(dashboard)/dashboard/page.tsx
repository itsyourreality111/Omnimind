import { auth } from '@clerk/nextjs/server'
import { createServerClient } from '@/lib/supabase/server'
import { Brain, Zap, TrendingUp, Clock, ArrowUpRight, CheckCircle, AlertCircle } from 'lucide-react'

export default async function DashboardPage() {
  const { userId } = auth()
  const supabase = createServerClient()

  // Fetch recent agent activity
  const { data: agentLogs } = await supabase
    .from('agent_logs')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(8)

  // Fetch user stats
  const { data: stats } = await supabase
    .from('user_stats')
    .select('*')
    .eq('user_id', userId)
    .single()

  return (
    <div className="p-8 max-w-6xl">
      {/* Header */}
      <div className="mb-8">
        <p className="text-xs font-mono text-[#00d4ff] tracking-widest uppercase mb-1">
          // Good morning
        </p>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">
          Here's what your AI did while you slept.
        </h1>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Hours Freed', value: stats?.hours_freed ?? '0', icon: Clock, color: 'text-[#00d4ff]' },
          { label: 'Content Queued', value: stats?.content_queued ?? '0', icon: Brain, color: 'text-amber-400' },
          { label: 'Leads Found', value: stats?.leads_found ?? '0', icon: Zap, color: 'text-purple-400' },
          { label: 'MRR Impact', value: `$${stats?.mrr_impact ?? '0'}`, icon: TrendingUp, color: 'text-emerald-400' },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-[#0d1525] border border-white/7 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono text-slate-500 uppercase tracking-wider">{label}</span>
              <Icon size={14} className={color} />
            </div>
            <div className={`text-3xl font-extrabold tracking-tight ${color}`}>{value}</div>
          </div>
        ))}
      </div>

      {/* Agent Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="bg-[#0d1525] border border-white/7 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-white/7 flex items-center justify-between">
              <span className="text-sm font-bold text-white">Agent Activity</span>
              <span className="text-xs font-mono text-slate-500">Last 24 hours</span>
            </div>
            <div className="divide-y divide-white/5">
              {agentLogs && agentLogs.length > 0 ? (
                agentLogs.map((log: any) => (
                  <div key={log.id} className="px-6 py-4 flex items-start gap-4">
                    <div className={`mt-0.5 flex-shrink-0 ${
                      log.status === 'done' ? 'text-emerald-400' :
                      log.status === 'review' ? 'text-amber-400' : 'text-[#00d4ff]'
                    }`}>
                      {log.status === 'done' ? <CheckCircle size={14} /> : <AlertCircle size={14} />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-300 leading-relaxed">{log.message}</p>
                      <p className="text-xs font-mono text-slate-600 mt-1">
                        {log.agent_type} · {new Date(log.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                    {log.status === 'review' && (
                      <button className="flex-shrink-0 text-xs bg-amber-400/10 text-amber-400 border border-amber-400/20 px-3 py-1 rounded-full hover:bg-amber-400/20 transition-colors font-semibold">
                        Review
                      </button>
                    )}
                  </div>
                ))
              ) : (
                <div className="px-6 py-12 text-center">
                  <Zap size={24} className="text-slate-600 mx-auto mb-3" />
                  <p className="text-sm text-slate-500">Agents are warming up.</p>
                  <p className="text-xs text-slate-600 mt-1">Check back after your first full night.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Quick actions */}
        <div className="space-y-4">
          <div className="bg-[#0d1525] border border-white/7 rounded-xl p-6">
            <h3 className="text-sm font-bold text-white mb-4">Quick Actions</h3>
            <div className="space-y-2">
              {[
                { label: 'Review content queue', href: '/content' },
                { label: 'Check lead pipeline', href: '/agents' },
                { label: 'View revenue report', href: '/revenue' },
                { label: 'Add to your brain', href: '/brain' },
              ].map(({ label, href }) => (
                <a
                  key={href}
                  href={href}
                  className="flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-white/5 transition-colors group"
                >
                  <span className="text-sm text-slate-400 group-hover:text-white transition-colors">{label}</span>
                  <ArrowUpRight size={12} className="text-slate-600 group-hover:text-[#00d4ff] transition-colors" />
                </a>
              ))}
            </div>
          </div>

          {/* Setup progress */}
          <div className="bg-[#0d1525] border border-white/7 rounded-xl p-6">
            <h3 className="text-sm font-bold text-white mb-1">Setup Progress</h3>
            <p className="text-xs text-slate-500 mb-4">Complete to unlock full power</p>
            <div className="space-y-3">
              {[
                { label: 'Connect Gmail', done: true },
                { label: 'Connect Notion', done: true },
                { label: 'Connect Stripe', done: false },
                { label: 'Upload first docs', done: false },
              ].map(({ label, done }) => (
                <div key={label} className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 ${
                    done ? 'bg-emerald-400/20 text-emerald-400' : 'bg-white/5 text-slate-600'
                  }`}>
                    {done && <CheckCircle size={10} />}
                  </div>
                  <span className={`text-xs ${done ? 'text-slate-400 line-through' : 'text-slate-300'}`}>
                    {label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
