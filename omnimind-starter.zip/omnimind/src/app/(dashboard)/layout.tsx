import { UserButton } from '@clerk/nextjs'
import Link from 'next/link'
import { redirect } from 'next/navigation'
import { auth } from '@clerk/nextjs/server'
import {
  Brain, Zap, FileText, TrendingUp,
  Settings, LayoutDashboard, ChevronRight
} from 'lucide-react'

const navItems = [
  { href: '/dashboard',  icon: LayoutDashboard, label: 'Overview' },
  { href: '/brain',      icon: Brain,            label: 'Second Brain' },
  { href: '/agents',     icon: Zap,              label: 'Agents' },
  { href: '/content',    icon: FileText,         label: 'Content' },
  { href: '/revenue',    icon: TrendingUp,       label: 'Revenue' },
  { href: '/settings',   icon: Settings,         label: 'Settings' },
]

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { userId } = auth()
  if (!userId) redirect('/login')

  return (
    <div className="flex h-screen bg-[#05080f] overflow-hidden">
      {/* Sidebar */}
      <aside className="w-60 flex-shrink-0 border-r border-white/7 flex flex-col bg-[#080d18]">
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-white/7">
          <span className="text-xl font-extrabold text-white tracking-tight">
            Omni<span className="text-[#00d4ff]">Mind</span>
          </span>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link
              key={href}
              href={href}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-all group text-sm font-semibold"
            >
              <Icon size={16} className="flex-shrink-0" />
              {label}
              <ChevronRight size={12} className="ml-auto opacity-0 group-hover:opacity-40 transition-opacity" />
            </Link>
          ))}
        </nav>

        {/* User */}
        <div className="p-4 border-t border-white/7 flex items-center gap-3">
          <UserButton afterSignOutUrl="/" />
          <span className="text-xs text-slate-500 font-mono truncate">My Workspace</span>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  )
}
