import Anthropic from '@anthropic-ai/sdk'
import OpenAI from 'openai'
import { createServiceClient } from '@/lib/supabase/server'

export const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
})

// Generate embedding for a piece of text
export async function embedText(text: string): Promise<number[]> {
  const response = await openai.embeddings.create({
    model: 'text-embedding-3-large',
    input: text.slice(0, 8000), // safety limit
  })
  return response.data[0].embedding
}

// Search user's knowledge graph by semantic similarity
export async function semanticSearch(
  query: string,
  userId: string,
  topK = 8
): Promise<{ content: string; source: string; similarity: number }[]> {
  const supabase = createServiceClient()
  const queryEmbedding = await embedText(query)

  const { data, error } = await supabase.rpc('match_knowledge_chunks', {
    query_embedding: queryEmbedding,
    match_user_id: userId,
    match_count: topK,
  })

  if (error) throw error
  return data ?? []
}

// RAG-powered chat: answer using user's knowledge graph
export async function ragChat(
  userMessage: string,
  userId: string,
  conversationHistory: { role: 'user' | 'assistant'; content: string }[] = []
) {
  // 1. Find relevant context from their brain
  const chunks = await semanticSearch(userMessage, userId, 6)

  const context = chunks.length > 0
    ? chunks.map((c) => `[${c.source}]: ${c.content}`).join('\n\n')
    : 'No relevant documents found in your knowledge base.'

  // 2. Stream response with context injected
  const stream = await anthropic.messages.stream({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1024,
    system: `You are OmniMind, a hyper-personalized AI assistant for this specific user.
You have access to their private knowledge base — their emails, documents, notes, and past work.
Answer questions using their data first. Be direct, specific, and useful.
If referencing their documents, mention the source briefly.

RELEVANT CONTEXT FROM THEIR KNOWLEDGE BASE:
${context}`,
    messages: [
      ...conversationHistory,
      { role: 'user', content: userMessage },
    ],
  })

  return stream
}

// Analyze user's data to build their profile
export async function buildUserProfile(userId: string, sampleChunks: string[]) {
  const response = await anthropic.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 2000,
    messages: [
      {
        role: 'user',
        content: `Analyze this person's digital footprint and extract a detailed profile.

DATA SAMPLES:
${sampleChunks.slice(0, 30).join('\n---\n')}

Return ONLY valid JSON with this exact structure:
{
  "professional_identity": "string — their role, expertise, what they do",
  "writing_style": "string — how they communicate, tone, vocabulary patterns",
  "active_goals": ["string"],
  "pain_points": ["string"],
  "key_relationships": ["name: relationship type"],
  "industry": "string",
  "content_topics": ["string — topics they write/care about"],
  "communication_tone": "formal|casual|technical|conversational"
}`,
      },
    ],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : '{}'
  try {
    return JSON.parse(text.replace(/```json|```/g, '').trim())
  } catch {
    return null
  }
}
